from django.apps import AppConfig


class BerandaConfig(AppConfig):
    name = 'beranda'
