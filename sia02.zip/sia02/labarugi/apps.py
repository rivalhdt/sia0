from django.apps import AppConfig


class LabarugiConfig(AppConfig):
    name = 'labarugi'
