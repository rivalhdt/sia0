from django.forms import ModelForm
from django import forms
from .models import *

class FormAkun(ModelForm):
    class Meta:
        model = akun
        fields = ['no','nama','jenis','unpo','norn']

        widgets = {
            'no' : forms.NumberInput({'class':'form-input-small'}),
            'nama' : forms.TextInput({'class':'form-input'}),
            'jenis' : forms.Select({'class':'form-input'}),
            'unpo' : forms.TextInput({'class':'form-input'}),
            'norn' : forms.TextInput({'class':'form-input'}),
        }