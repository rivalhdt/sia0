from django.apps import AppConfig


class NeracaConfig(AppConfig):
    name = 'neraca'
