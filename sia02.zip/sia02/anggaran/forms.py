from django.forms import ModelForm
from django import forms
from akun.models import *

class FormAkun(ModelForm):
    class Meta:
        model = akun
        fields = ['anggaran',]

        widgets = {
            'anggaran' : forms.NumberInput({'class':'form-input-small'}),
        }