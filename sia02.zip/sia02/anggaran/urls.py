from django.urls import path
from .views import *

app_name = 'anggaran'
urlpatterns = [
    path('dashboard', dashboard, name='dashboard'),
    path('ubah/<int:id_akun>', ubah_akun, name='ubah'),
    
]
